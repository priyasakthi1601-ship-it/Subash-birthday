# Happy Birthday, Subash 🌌

A personalized birthday website — moving stars, glassmorphism, a 7-photo gallery,
a personal letter, a secret "Open My Heart" page, and confetti.

## Add background music (optional)

The player is already wired up — you just need to drop a file in:

1. Find any soft/romantic instrumental MP3 (lofi, piano, acoustic — royalty-free
   sources like **Pixabay Music**, **YouTube Audio Library**, or **Free Music
   Archive** are safe to use).
2. Rename it to `bgm.mp3`.
3. Put it in `assets/music/bgm.mp3` (replacing the empty placeholder).
4. That's it — the floating note button top-right plays/pauses it, and it starts
   automatically the moment he clicks "Open your sky" (some phone browsers block
   autoplay with sound until the button is tapped once — totally normal).

## Preview it locally

Just double-click `index.html` — it opens directly in any browser, no server needed.

## Put it online (free) — GitHub Pages

1. Create a new **public** repo on GitHub (e.g. `subash-birthday`).
2. Upload all files in this folder, keeping the same structure:
   ```
   index.html
   style.css
   script.js
   assets/photos/1.jpg ... 7.jpg
   assets/music/bgm.mp3
   ```
3. Go to **Settings → Pages**, set branch to `main` and folder to `/ (root)`, save.
4. In a minute or two your site is live at:
   `https://YOUR-USERNAME.github.io/subash-birthday/`

## Put it online (free) — Netlify (faster, drag-and-drop)

1. Go to [app.netlify.com/drop](https://app.netlify.com/drop).
2. Drag this whole folder onto the page.
3. Netlify gives you a live link immediately (you can rename it in Site settings →
   Change site name, e.g. `subash-birthday.netlify.app`).

## Editing later

- **Letter text** — open `index.html`, search for `<section id="letter"`, edit
  the paragraphs directly.
- **Photos** — replace any file in `assets/photos/` (keep the same filenames
  `1.jpg`–`7.jpg`), or add more and extend the `photos` array near the top of
  `script.js`.
- **Colors** — all colors live at the top of `style.css` under `:root`, e.g.
  `--gold`, `--cyan`, `--navy`.

Happy birthday to Subash. 🤍
